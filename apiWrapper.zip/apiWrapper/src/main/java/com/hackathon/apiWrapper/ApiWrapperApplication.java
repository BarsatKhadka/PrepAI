package com.hackathon.apiWrapper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiWrapperApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiWrapperApplication.class, args);
	}

}
