package com.hackathon.apiWrapper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiWrapperApplicationTests {

	@Test
	void contextLoads() {
	}

}
